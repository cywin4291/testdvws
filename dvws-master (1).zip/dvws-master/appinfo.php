
<?php

// Show all information, defaults to INFO_ALL
phpinfo();

// Show just the module information.
phpinfo(INFO_MODULES);

?>
